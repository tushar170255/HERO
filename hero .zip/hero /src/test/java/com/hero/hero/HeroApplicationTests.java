package com.hero.hero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeroApplicationTests {

	@Test
	void contextLoads() {
	}

}
